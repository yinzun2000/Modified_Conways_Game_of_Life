library(fields)

library(RColorBrewer)

ReSort  <-  function(v.i,tdim)
{
  v.o <-  array(NA,dim=c(tdim-1,tdim-1)) 

  zlen  <-  length(v.i)
  if (zlen != tdim*(tdim-1)/2)
    stop("The dimension doesn't match the length of input.")

  pt  <-  1
  for (i in 1:(tdim-1))
  {
    v.o[i,i:(tdim-1)] <-  v.i[pt:(pt+tdim-i-1)]
    pt  <-  pt+tdim-i
  }
  return(v.o)
}

ReShape <-  function(v.i,tsub,tsup,idx)
{
  ttlen <-  (tsub-1)*(tsup-1)
  v.o <-  array(NA,dim=c(ttlen,ttlen))

  zdvi  <-  (tsup-1)*tsup/2

  zseq  <-  seq((tsup-1),1)

  prow  <-  0
  for (i in 1:zdvi)
  {
    #locate the range of sub-matrix of v.o
    nx  <-  prow+1
    if (prow == 0)
    {
      ny  <-  i
    } else
      ny  <-  prow+i-sum(zseq[1:prow])

    if (ny == (tsup-1))
      prow  <-  prow+1

    if (idx == 1)
    {
      v.o[((tsub-1)*(nx-1)+1):((tsub-1)*nx),((tsub-1)*(ny-1)+1):((tsub-1)*ny)]  <-
        ReSort(v.i[i,],tsub)
    } else
      v.o[((tsub-1)*(nx-1)+1):((tsub-1)*nx),((tsub-1)*(ny-1)+1):((tsub-1)*ny)]  <-
        ReSort(v.i[,i],tsub)

  }

  print('Success: use t(apply(mat,2,rev) for image.plot)')
  return(v.o)
}
