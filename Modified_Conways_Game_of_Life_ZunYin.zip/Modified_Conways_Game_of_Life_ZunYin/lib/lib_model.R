#Here we write the model in R

CGLNextStep <-  function(v.i,dia.s=3,dia.g=3,r.min=0.2,r.max=0.4,
                         c.min=0.2,c.max=0.4)
{
    prob.gs.s <-  GetGS(dia.s,r.min=r.min,r.max=r.max,
                      c.min=c.min,c.max=c.max)
    prob.gs.g <-  GetGS(dia.g,r.min=r.min,r.max=r.max,
                      c.min=c.min,c.max=c.max)
    prob.gs <-  list(s=prob.gs.s$s,g=prob.gs.g$g)
    #c.num   <-  (2*dia+1)**2-1
    n.d <-  dim(v.i)[1]
    v.tt    <-  array(NA,dim=c(n.d*3,n.d*3))
    v.tt[1:n.d,1:n.d]   <-  v.i
    v.tt[(n.d+1):(2*n.d),1:n.d]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),1:n.d] <-  v.i
    v.tt[1:n.d,(n.d+1):(2*n.d)]   <-  v.i
    v.tt[(n.d+1):(2*n.d),(n.d+1):(2*n.d)]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),(n.d+1):(2*n.d)] <-  v.i
    v.tt[1:n.d,(2*n.d+1):(3*n.d)]   <-  v.i
    v.tt[(n.d+1):(2*n.d),(2*n.d+1):(3*n.d)]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),(2*n.d+1):(3*n.d)] <-  v.i

    v.o <-  v.i
    for (nx in 1:n.d)
    for (ny in 1:n.d)
    {
        sum.t.s   <-  (sum(v.tt[(n.d+nx-dia.s):(n.d+nx+dia.s),
                             (n.d+ny-dia.s):(n.d+ny+dia.s)])-
                    v.tt[n.d+nx,n.d+ny])
        sum.t.g   <-  (sum(v.tt[(n.d+nx-dia.g):(n.d+nx+dia.g),
                             (n.d+ny-dia.g):(n.d+ny+dia.g)])-
                    v.tt[n.d+nx,n.d+ny])
        x.ran   <-  runif(1,0,1)
        if (v.tt[n.d+nx,n.d+ny] == 0)
        {
            if (prob.gs$g[sum.t.g+1] <= x.ran)
                v.o[nx,ny]  <-  1
        } else
        {
            if (prob.gs$s[sum.t.s+1] >= x.ran)
                v.o[nx,ny]  <-  0
        }
    }

    return(v.o)
}

GetGS       <-  function(dia=3,r.min=0.2,r.max=0.4,
                         c.min=0.2,c.max=0.4)
{
    n.len   <-  (2*dia+1)**2
    p.g <-  array(NA,dim=n.len)
    p.s <-  array(NA,dim=n.len)

    sap.t   <-  seq(0,n.len-1)/n.len

    zr  <-  sap.t
    zpc <-  (zr-c.min)/(c.max-c.min)
    zpc[zr <= c.min] <-  0
    zpc[zr >= c.max] <-  1

    zr  <-  1-sap.t
    zpr <-  (zr-r.min)/(r.max-r.min)
    zpr[zr <= r.min] <-  0
    zpr[zr >= r.max] <-  1
    p.s <-  zpr*zpc

    zr  <-  pmax(0,sap.t- 1/n.len)
    zpc <-  (zr-c.min)/(c.max-c.min)
    zpc[zr <= c.min] <-  0
    zpc[zr >= c.max] <-  1

    zr  <-  pmax(1-sap.t-1/n.len,0)
    zpr <-  (zr-r.min)/(r.max-r.min)
    zpr[zr <= r.min] <-  0
    zpr[zr >= r.max] <-  1
    p.g <-  zpr*zpc

    v.o <-  list(g=p.g,s=p.s)
    return(v.o)
}

Smooth  <-  function(v.i){
    n.d <-  dim(v.i)[1]
    v.tt    <-  array(NA,dim=c(n.d*3,n.d*3))
    v.tt[1:n.d,1:n.d]   <-  v.i
    v.tt[(n.d+1):(2*n.d),1:n.d]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),1:n.d] <-  v.i
    v.tt[1:n.d,(n.d+1):(2*n.d)]   <-  v.i
    v.tt[(n.d+1):(2*n.d),(n.d+1):(2*n.d)]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),(n.d+1):(2*n.d)] <-  v.i
    v.tt[1:n.d,(2*n.d+1):(3*n.d)]   <-  v.i
    v.tt[(n.d+1):(2*n.d),(2*n.d+1):(3*n.d)]   <-  v.i
    v.tt[(2*n.d+1):(3*n.d),(2*n.d+1):(3*n.d)] <-  v.i

    m.h   <-  n.d+1
    m.e   <-  2*n.d
    m.h   <-  n.d+1
    m.e   <-  2*n.d

    v.o <-  v.i + v.tt[(m.h-1):(m.e-1),m.h:m.e] +
            v.tt[(m.h+1):(m.e+1),m.h:m.e] +
            v.tt[m.h:m.e,(m.h-1):(m.e-1)] +
            v.tt[m.h:m.e,(m.h+1):(m.e+1)] +
            v.tt[(m.h+1):(m.e+1),(m.h+1):(m.e+1)] +
            v.tt[(m.h-1):(m.e-1),(m.h-1):(m.e-1)] +
            v.tt[(m.h+1):(m.e+1),(m.h-1):(m.e-1)] +
            v.tt[(m.h-1):(m.e-1),(m.h+1):(m.e+1)]

    return(round(v.o*1.2/9,0))
}

CalSmoo <-  function(v.i,n.c=1){
    v.t <-  v.i
    for (i in 1:n.c)
    {
        v.o <-  Smooth(v.t)
        v.t <-  v.o
    }
    return(v.o)
}
