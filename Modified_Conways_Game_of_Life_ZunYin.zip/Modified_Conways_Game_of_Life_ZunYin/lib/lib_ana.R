GetNum <- function(ti,tk)
{
  t.t <-  seq(9,1)
  if (ti == 1)
  {
    v.o <-  tk-ti
  } else
    v.o <-  sum(t.t[1:(ti-1)])+tk-ti

  return(v.o)
}

GetPair <- function(tind,tdim)
{
  zlen  <-  tdim*(tdim - 1)/2
  t.t <-  seq((tdim-1),1)
  t.c <-  t.t

  for (i in 2:length(t.c))
    t.c[i]  <-  t.t[i] + t.c[i-1]

  for (i in 1:length(t.c))
  {
    if (tind <= t.c[i])
    {
        nx.o  <-  i
      if (i == 1)
      {
        ny.o  <-  tind+i
      } else
        ny.o  <-  tind-t.c[i-1]+i

      v.o <-  c(nx.o,ny.o)
      return(v.o)
    }
  }
}

MoranI  <-  function(v.i)
{
  zdim  <-  dim(v.i)[1]

  z.mean  <-  mean(v.i)

  z.mat <-  v.i - z.mean

  z.var   <-  sum(z.mat**2)

  z.h <-  z.mat[,1:(zdim-1)]*z.mat[,2:zdim]
  z.v <-  z.mat[1:(zdim-1),]*z.mat[2:zdim,]
  #z.sl  <-  z.mat[1:(zdim-1),1:(zdim-1)]*z.mat[2:zdim,2:zdim]
  #z.sr  <-  z.mat[2:zdim,1:(zdim-1)]*z.mat[1:(zdim-1),2:zdim]

  #z.sum <-  sum(z.h) + sum(z.v) + sum(z.sl) + sum(z.sr)
  #z.cp  <-  length(z.h) + length(z.v) + length(z.sl) + length(z.sr)
  z.sum <-  sum(z.h) + sum(z.v)
  z.cp  <-  length(z.h) + length(z.v)

  v.o <-  z.sum*(zdim**2)/(z.cp*z.var)

  return(v.o)
}
