source('lib/lib_plot.R')

if (!exists('mean.i'))
  source('read/exp1/read_exp1.R')

i <-  100

pat.m.res <-  ReShape(mean.i[,,100,1],10,10,1)
pat.s.res <-  ReShape(mean.i[,,100,2],10,10,1)

pat.m.coe <-  ReShape(mean.i[,,100,1],10,10,2)
pat.s.coe <-  ReShape(mean.i[,,100,2],10,10,2)

pdf('fig/exp1_sens_stable_mean.pdf',height=6,width=12)
par(oma=c(.5,2,2,2.5)+.1,mar=c(.5,3,3,2)+.1,cex=1.5)

cex.t <-  .95
cex.l <-  1.5

set.panel(1,2)
image(seq(1,81),seq(1,81),t(apply(pat.m.res,2,rev)),
      zlim=c(0,0.8),col=tim.colors(50),axes=F,xlab='',
      ylab='')
box()
for (i in 1:8)
{
  abline(h=9*i+.5)
  abline(v=9*i+.5)
}

axis(3,at=seq(5,77,9),labels=seq(.15,.95,.1),cex.axis=cex.t)
axis(2,at=seq(5,77,9),labels=seq(.85,.05,-.1),cex.axis=cex.t)
mtext(2,text=expression(italic(R)[min]),line=2.5,cex=cex.l)
mtext(3,text=expression(italic(R)[max]),line=2.5,cex=cex.l)

arrows(36.5,35,45.5,35,length=.08,angle=20,lwd=2,col=2)
arrows(35,36.5,35,45.5,length=.08,angle=20,lwd=2,col=2)
text(41,31,labels=expression(italic(C)[max]),col=2,cex=1.2)
text(31,41,labels=expression(italic(C)[min]),col=2,cex=1.2)

image.plot(seq(1,81),seq(1,81),t(apply(pat.m.coe,2,rev)),
           zlim=c(0,0.8),col=tim.colors(50),
           smallplot=c(0.92,0.97,.1,.85),axes=F,xlab='',ylab='')

box()
for (i in 1:8)
{
  abline(h=9*i+.5)
  abline(v=9*i+.5)
}

axis(3,at=seq(5,77,9),labels=seq(.15,.95,.1),cex.axis=cex.t)
axis(2,at=seq(5,77,9),labels=seq(.85,.05,-.1),cex.axis=cex.t)
mtext(2,text=expression(italic(C)[min]),line=2.5,cex=cex.l)
mtext(3,text=expression(italic(C)[max]),line=2.5,cex=cex.l)

arrows(36.5,35,45.5,35,length=.08,angle=20,lwd=2,col=2)
arrows(35,36.5,35,45.5,length=.08,angle=20,lwd=2,col=2)
text(41,31,labels=expression(italic(R)[max]),col=2,cex=1.2)
text(31,41,labels=expression(italic(R)[min]),col=2,cex=1.2)

set.panel(1,1)
dev.off()

pdf('fig/exp1_sens_stable_sd.pdf',height=6,width=12)
par(oma=c(.5,2,2,2.5)+.1,mar=c(.5,3,3,2)+.1,cex=1.5)

cex.t <-  .95
cex.l <-  1.5

set.panel(1,2)

rr.log  <-  log(pat.s.res/pat.m.res)
rr.log[!is.na(rr.log) & rr.log < -5]  <-  -5
rr.log[!is.na(rr.log) & rr.log > 2] <-  2

image(seq(1,81),seq(1,81),t(apply(rr.log,2,rev)),
      zlim=c(-5,2),col=tim.colors(50),axes=F,xlab='',
      ylab='')
box()
for (i in 1:8)
{
  abline(h=9*i+.5)
  abline(v=9*i+.5)
}

axis(3,at=seq(5,77,9),labels=seq(.15,.95,.1),cex.axis=cex.t)
axis(2,at=seq(5,77,9),labels=seq(.85,.05,-.1),cex.axis=cex.t)
mtext(2,text=expression(italic(R)[min]),line=2.5,cex=cex.l)
mtext(3,text=expression(italic(R)[max]),line=2.5,cex=cex.l)

arrows(36.5,35,45.5,35,length=.08,angle=20,lwd=2,col=2)
arrows(35,36.5,35,45.5,length=.08,angle=20,lwd=2,col=2)
text(41,31,labels=expression(italic(C)[max]),col=2,cex=1.2)
text(31,41,labels=expression(italic(C)[min]),col=2,cex=1.2)

cc.log  <-  log(pat.s.coe/pat.m.coe)
cc.log[!is.na(cc.log) & cc.log < -5]  <-  -5
cc.log[!is.na(cc.log) & cc.log > 2] <-  2

image.plot(seq(1,81),seq(1,81),t(apply(cc.log,2,rev)),
           zlim=c(-5,2),col=tim.colors(50),
           smallplot=c(0.92,0.97,.1,.85),axes=F,xlab='',ylab='',
           axis.args=list(at=seq(-5,2),labels=round(exp(seq(-5,2)),2)))

box()
for (i in 1:8)
{
  abline(h=9*i+.5)
  abline(v=9*i+.5)
}

axis(3,at=seq(5,77,9),labels=seq(.15,.95,.1),cex.axis=cex.t)
axis(2,at=seq(5,77,9),labels=seq(.85,.05,-.1),cex.axis=cex.t)
mtext(2,text=expression(italic(C)[min]),line=2.5,cex=cex.l)
mtext(3,text=expression(italic(C)[max]),line=2.5,cex=cex.l)

arrows(36.5,35,45.5,35,length=.08,angle=20,lwd=2,col=2)
arrows(35,36.5,35,45.5,length=.08,angle=20,lwd=2,col=2)
text(41,31,labels=expression(italic(R)[max]),col=2,cex=1.2)
text(31,41,labels=expression(italic(R)[min]),col=2,cex=1.2)

set.panel(1,1)
dev.off()
