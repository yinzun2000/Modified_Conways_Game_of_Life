library(fields)
if (!exists('dif.da'))
  source('ana/exp2/ana_cor.R')

col.r <-  rgb(1,0,0,.5)
col.b <-  rgb(0,0,1,.5)

pdf('fig/indep_ts.pdf',height=6,width=8)
par(oma=c(.5,.5,.5,.5)+.1,mar=c(3,3,1,1)+.1,cex=1.5)
plot(1,1,type='n',xlim=c(0,20),ylim=range(dif.da,dif.ra),
     xlab='',ylab='',axes=F)
boxplot(t(dif.da),xlab='',ylab='',axes=F,
        col=col.r,add=T,at=seq(1.5,17.5,length.out=5))
boxplot(t(dif.ra),xlab='',ylab='',axes=F,
        col=col.b,add=T,at=seq(2.5,18.5,length.out=5))
box()
axis(2)
axis(1,at=seq(2,18,4),labels=round(zth,1))
mtext(1,text='Spatial mean',cex=1.5,line=2.3)
mtext(2,text='Different rate',cex=1.5,line=2.3)

legend('bottomright',fill=c(col.r,col.b),
       bty='n',cex=1,legend=c('Model','Random'))

dev.off()

pdf('fig/indep_pat.pdf',height=7,width=8)
par(oma=c(.5,.5,.5,.5)+.1,mar=c(4,3,.1,1)+.1,cex=1.5)
set.panel(2,2)
image.plot(apply(pat.i[4,,,],c(1,2),mean),zlim=c(.35,1))
mtext(1,text='Spatial Mean = 0.4',line=2.6,cex=1.2)
image.plot(apply(pat.i[5,,,],c(1,2),mean),zlim=c(.35,1))
mtext(1,text='Spatial Mean = 0.5',line=2.6,cex=1.2)
image.plot(apply(pat.i[6,,,],c(1,2),mean),zlim=c(.35,1))
mtext(1,text='Spatial Mean = 0.6',line=2.6,cex=1.2)
image.plot(apply(pat.i[7,,,],c(1,2),mean),zlim=c(.35,1))
mtext(1,text='Spatial Mean = 0.7',line=2.6,cex=1.2)
set.panel(1,1)
dev.off()
