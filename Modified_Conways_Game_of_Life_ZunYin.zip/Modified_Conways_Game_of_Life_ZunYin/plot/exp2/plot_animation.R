library('animation')

if (!exists('pat.i'))
  source('read/exp2/read_exp2.R')

#saveGIF({
#          par(oma=rep(.5,4),mar=rep(.1,4))
#          for (i in 1:100)
#          {
#            image(seq(1,100),seq(1,100),pat.i[4,,,i],axes=F)
#            box
#          }
#        },
#        movie.name = "animation.gif", clean = TRUE, interval=0.5)

pdf('fig/equilibrium.pdf',height=6,width=8)
par(mfrow=c(2,1),oma=c(3,3,1,1)+.5,mar=rep(0,4),cex=1.5)

plot(pat.m[4,],type='l',xlab='',ylab='',axes=F)
box()
axis(2)
text(910,.485,labels='Mean = 0.4')
text(910,.465,labels='Std = 0.024')
mtext(2,text='Spatial mean',line=2.3,cex=1.5)
plot(mor.i[4,],type='l',xlab='',ylab='',axes=F)
box()
axis(1)
axis(2)
text(910,.595,labels='Mean = .55')
text(910,.585,labels='Std = 0.014')
mtext(1,text='Simulation time step',line=2.3,cex=1.5)
mtext(2,text='Moran\'s I',line=2.3,cex=1.5)
dev.off()
