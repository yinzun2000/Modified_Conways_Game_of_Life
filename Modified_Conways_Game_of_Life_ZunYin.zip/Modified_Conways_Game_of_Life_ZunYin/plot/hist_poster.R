

pdf('fig/hist1.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  -5
sd.i <-  3

w.d <-  15

c.t <-  rgb(17/255,141/255,255/255)

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()

pdf('fig/hist2.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  0
sd.i <-  2

c.t <-  rgb(83/255,213/255,42/255)

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()

pdf('fig/hist3.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  5
sd.i <-  1

c.t <-  rgb(252/255,75/255,62/255)

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()

pdf('fig/hist_het.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  0
sd.i <-  2.5

c.t <-  rgb(73/255,73/255,73/255)

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()

pdf('fig/hist_hom.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  0
sd.i <-  1.5

c.t <-  rgb(204/255,204/255,204/255)

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()

pdf('fig/hist_het.pdf',height=5,width=5)

par(oma=rep(0,4),mar=rep(.5,4))

m.i <-  0
sd.i <-  2.5

c.t <-  'gray'

curve(exp(-.5*((x-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi)),
      -10,10,lwd=w.d,xlim=c(-10,10),axes=F,
      ylim=c(-.005,.4),col=c.t)

mm  <-  exp(-.5*((m.i-m.i)/sd.i)^2)/(sd.i*sqrt(2*pi))
segments(-10,-.005,-10,.4,lwd=w.d,col=c.t)
segments(-10,-.005,10,-.005,lwd=w.d,col=c.t)
segments(m.i,-.005,m.i,mm,lwd=w.d,lty=2,col=c.t)

dev.off()
