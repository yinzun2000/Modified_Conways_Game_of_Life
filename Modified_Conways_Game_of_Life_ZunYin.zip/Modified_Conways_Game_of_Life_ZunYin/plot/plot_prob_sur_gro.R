zlen  <-  200
xi  <-  1/25
r.min <-  .15
r.max <-  .65

c.min <-  .15
c.max <-  .55

xx  <-  seq(0,1,length.out=zlen)

#survive depends on co-existence
s.c  <- xx 
#survive depends on resources
s.r  <- xx 

for (i in 1:zlen)
{
  xx.tmp  <-  xx[i]
  if (xx.tmp <= c.min)
  {
    s.c[i]  <-  0
  } else if (xx.tmp >= c.max)
  {
    s.c[i]  <-  1
  } else
    s.c[i]  <-  (xx.tmp-c.min)/(c.max-c.min)

  xx.tmp  <-  1-xx[i]
  if (xx.tmp <= r.min)
  {
    s.r[i]  <-  0
  } else if (xx.tmp >= r.max)
  {
    s.r[i]  <-  1
  } else
    s.r[i]  <-  (xx.tmp-r.min)/(r.max-r.min)
}

s.p <-  s.r*s.c


#growth depends on co-existence
g.c  <- xx
#survive depends on resources
g.r  <- xx 

for (i in 1:zlen)
{
  xx.tmp  <-  max(0,xx[i]-xi)
  if (xx.tmp <= c.min)
  {
    g.c[i]  <-  0
  } else if (xx.tmp >= c.max)
  {
    g.c[i]  <-  1
  } else
    g.c[i]  <-  (xx.tmp-c.min)/(c.max-c.min)

  xx.tmp  <-  max(0,1-xx[i]-xi)
  if (xx.tmp <= r.min)
  {
    g.r[i]  <-  0
  } else if (xx.tmp >= r.max)
  {
    g.r[i]  <-  1
  } else
    g.r[i]  <-  (xx.tmp-r.min)/(r.max-r.min)
}

g.p <-  g.r*g.c

pdf('fig/example_prob.pdf',height=5,width=8)
par(oma=c(.5,.5,.5,.5)+.1,mar=c(3,3,.5,.5)+.1,cex=1.5)

plot(xx,s.r,type='l',xlab='',ylab='',lty=3,col=1,lwd=3)
mtext(1,text=expression(gamma),line=2.2,cex=1.8)
mtext(2,text='Probability',line=2.2,cex=1.5)
lines(xx,s.c,lty=2,col=1,lwd=3)
#lines(xx,s.p,col=2,lwd=2)
lines(xx,g.p,col=2,lwd=2)

legend('right',bty='n',lty=c(3,2,1),lwd=c(3,3,2),col=c(1,1,2),
       legend=c(expression(italic(P)[resource]),expression(italic(P)[co-existence]),
                expression(italic(P)[s])))

arrows(1-r.min,.2,1-r.min,.05,length=0.1,angle=20,lwd=2)
text(1-r.min,.25,labels=expression(italic(R)[min]))
arrows(1-r.max,.8,1-r.max,.95,length=0.1,angle=20,lwd=2)
text(1-r.max,.75,labels=expression(italic(R)[max]))
arrows(c.min,.2,c.min,.05,length=0.1,angle=20,lwd=2)
text(c.min,.25,labels=expression(italic(C)[min]))
arrows(c.max,.8,c.max,.95,length=0.1,angle=20,lwd=2)
text(c.max,.75,labels=expression(italic(C)[max]))

dev.off()

