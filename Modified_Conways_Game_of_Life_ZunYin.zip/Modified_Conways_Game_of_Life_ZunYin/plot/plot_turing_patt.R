source('lib/lib_plot.R')

pp.2    <-  as.matrix(read.table('dat/pp.o.1'))
pp.1    <-  as.matrix(read.table('dat/pp.o.125'))
pp.3    <-  as.matrix(read.table('dat/pp.o.075'))

n.col   <-  2

col.1   <-  colorRampPalette(c('white','#48B3FF'))(n.col)
col.2   <-  colorRampPalette(c('white','#53D52A'))(n.col)
col.3   <-  colorRampPalette(c('white','#FC4B3E'))(n.col)
col.4   <-  colorRampPalette(c('white','#B0B0B0'))(n.col)

bor <-  0.025
lwd.t   <-  2

pdf('fig/pat_1_1.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(pp.1,col=col.1,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_1_2.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(t(pp.1),col=col.1,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_1_3.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.1),2,rev),col=col.1,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_1_4.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.1),1,rev),col=col.1,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()


pdf('fig/pat_2_1.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(pp.2,col=col.2,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_2_2.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(t(pp.2),col=col.2,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_2_3.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.2),2,rev),col=col.2,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_2_4.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.2),1,rev),col=col.2,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_3_1.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(pp.3,col=col.3,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_3_2.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(t(pp.3),col=col.3,axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_3_3.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.3),2,rev),col=col.3,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_3_4.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(t(pp.3),1,rev),col=col.3,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()

pdf('fig/pat_gray.pdf',height=5,width=5)
par(mar=rep(bor,4),oma=rep(bor,4),bg='white')
image(apply(pp.3,1,rev),col=col.4,
      axes=F,xlab='',ylab='')
box(lwd=lwd.t)
dev.off()
