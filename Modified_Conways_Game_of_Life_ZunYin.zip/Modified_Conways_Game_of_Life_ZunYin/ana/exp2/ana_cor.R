source('lib/lib_ana.R')

if (!exists('pat.i'))
  source('read/exp2/read_exp2.R')

CalDiff  <-  function(v1.i,v2.i)
{
  kk.t  <-  v1.i+v2.i
  v.o <-  length(kk.t[kk.t != 1])/length(kk.t)
  return(v.o)
}

CalDiffTS  <-  function(v.i,arr.i)
{
  zlen  <-  dim(arr.i)[3]

  v.o <-  array(NA,dim=zlen)
  p.o <-  array(NA,dim=zlen)

  for (i in 1:zlen)
  {
    v.tmp <-  arr.i[,,i] + v.i
    v.o[i]  <-  length(v.tmp[v.tmp != 1])/length(v.tmp)
  }

  return(v.o)
}

pat.m   <-  apply(pat.i,c(1,4),mean)
pat.mm  <-  apply(pat.m,1,mean)
pat.sd  <-  apply(pat.i,c(1,4),sd)

mor.i <-  array(NA,dim=dim(pat.i)[c(1,4)])

for (i in 1:dim(pat.i)[1])
for (k in 1:dim(pat.i)[4])
  mor.i[i,k]  <-  MoranI(pat.i[i,,,k])


mor.m   <-  apply(mor.i,1,mean)
mor.sd  <-  apply(mor.i,1,sd)

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#number of simulation length
zlen  <-  1000

#dim*dim
znumm <-  10000
#number of simulation
znumt <-  5

zth <-  pat.mm[3:7]

dif.ra  <-  array(NA,dim=c(znumt,zlen))
dif.da  <-  array(NA,dim=c(znumt,zlen))

for (i in 1:znumt)
for (k in 1:zlen)
{
  d1.tmp <- runif(znumm,0,1)
  d1.tmp[d1.tmp <= zth[i]] <-  0
  d1.tmp[d1.tmp > zth[i]]  <-  1

  d2.tmp <- runif(znumm,0,1)
  d2.tmp[d2.tmp <= zth[i]] <-  0
  d2.tmp[d2.tmp > zth[i]]  <-  1

  dd.tmp  <-  d1.tmp + d2.tmp

  dif.ra[i,k] <-  length(dd.tmp[dd.tmp != 1])/length(dd.tmp)

  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  id.tmp  <-  sample(seq(1,1000),2)
  d1.tmp <- pat.i[i+2,,,id.tmp[1]]
  d1.tmp[d1.tmp <= zth[i]] <-  0
  d1.tmp[d1.tmp > zth[i]]  <-  1

  d2.tmp <- pat.i[i+2,,,id.tmp[2]]
  d2.tmp[d2.tmp <= zth[i]] <-  0
  d2.tmp[d2.tmp > zth[i]]  <-  1

  dd.tmp  <-  d1.tmp + d2.tmp

  dif.da[i,k] <-  length(dd.tmp[dd.tmp != 1])/length(dd.tmp)
}
