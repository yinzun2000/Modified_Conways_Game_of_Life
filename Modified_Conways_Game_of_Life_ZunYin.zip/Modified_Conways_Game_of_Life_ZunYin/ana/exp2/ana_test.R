if (!exists('pat.i'))
  source('read/exp2/read_exp2.R')

#number of simulation length
zlen  <-  1000

#dim*dim
znumm <-  10000
#number of simulation
znumt <-  5

#zth <-  seq(.1,.7,.1)
zth <-  

cor.tt  <-  array(NA,dim=c(znumt,zlen))

for (i in 1:znumt)
for (k in 1:zlen)
{
  d1.tmp <- runif(znumm,0,1)
  d1.tmp[d1.tmp <= zth[i]] <-  0
  d1.tmp[d1.tmp > zth[i]]  <-  1

  d2.tmp <- runif(znumm,0,1)
  d2.tmp[d2.tmp <= zth[i]] <-  0
  d2.tmp[d2.tmp > zth[i]]  <-  1

  dd.tmp  <-  d1.tmp + d2.tmp

  cor.tt[i,k] <-  length(dd.tmp[dd.tmp != 1])/length(dd.tmp)
}
