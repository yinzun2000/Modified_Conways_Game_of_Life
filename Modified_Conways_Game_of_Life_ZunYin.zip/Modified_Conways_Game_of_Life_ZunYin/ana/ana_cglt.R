library('fields')
source('lib/lib_ana.R')

zdim  <-  100
zlen  <-  1000

d.tmp <-  as.matrix(read.table('dat/pat_test.txt'))

pat.i <-  array(NA,dim=c(100,100,1000))
pat.m <-  array(NA,dim=1000)
pat.sd <-  array(NA,dim=1000)
pat.mor <-  array(NA,dim=1000)

for (i in 1:zlen)
{
  pat.i[,,i]  <-  d.tmp[(zdim*(i-1)+1):(zdim*i),]
  pat.mor[i]  <-  MoranI(pat.i[,,i])
}

pat.m <-  apply(pat.i,3,mean)
pat.sd <-  apply(pat.i,3,sd)

