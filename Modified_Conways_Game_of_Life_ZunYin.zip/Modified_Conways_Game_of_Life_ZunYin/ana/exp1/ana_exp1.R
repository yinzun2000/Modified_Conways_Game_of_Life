#here we test if the simulation reach equilibrium
library(Kendall)

if (!exists('mean.i'))
  source('read/exp1/read_exp1.R')

l.s <-  71
l.e <-  100

p.mat  <-  array(NA,dim=dim(mean.i)[1:2])
tr.mat <-  array(NA,dim=dim(mean.i)[1:2])

mat.sub <-  mean.i[,,l.s:l.e,1]

for (i in 1:dim(p.mat)[1])
for (k in 1:dim(p.mat)[2])
{
  if (sum(mat.sub[i,k,]) < 1e-10)
  {
    p.mat[i,k]  <-  0
    tr.mat[i,k]  <-  0
  }
  else
  {
    p.mat[i,k]  <-  as.numeric(MannKendall(mat.sub[i,k,])$sl)
    tr.mat[i,k] <-  as.numeric(sens.slope(mat.sub[i,k,])$estimate)
  }
}

q.mat <-  p.mat

q.mat[q.mat > .05]  <-  1
q.mat[q.mat <= .05]  <-  0
