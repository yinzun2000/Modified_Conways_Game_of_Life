#here we will select different combinations of res_min, res_max, coe_min, coe_max
library(Kendall)
source('lib/lib_ana.R')

if (!exists('mean.i'))
  source('read/exp1/read_exp1.R')

#mean value from 0.1 to 0.7

val.i <-  seq(.1,.7,.1)
par.i <-  seq(.05,.95,.1)


loc.o <-  array(0,dim=c(length(val.i),4))

zsum  <-  apply(mean.i[,,90:100,1],c(1,2),mean)

dx  <-  dim(zsum)[1]
dy  <-  dim(zsum)[2]

for (i in 1:length(val.i))
{
  mat.tmp <-  abs(zsum - val.i[i])
  #x axis is for res
  #y axis is for coe
  loc.tmp <-  which(mat.tmp == min(mat.tmp), arr.ind=T)
  #loc.o[i,1:2] <-  GetPair(loc.tmp[1],length(par.i))
  #loc.o[i,3:4] <-  GetPair(loc.tmp[2],length(par.i))
  loc.o[i,1:2] <-  par.i[GetPair(loc.tmp[1],length(par.i))]
  loc.o[i,3:4] <-  par.i[GetPair(loc.tmp[2],length(par.i))]
}

write.table(loc.o,'exp1/dat/loc_parameter.txt',
            col.names=F,row.names=F,sep='\t')
