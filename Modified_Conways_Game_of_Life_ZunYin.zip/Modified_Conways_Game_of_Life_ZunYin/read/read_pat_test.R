filei   <-  'dat/pat_test.txt'

d.tmp   <-  as.matrix(read.table(filei))

dim.p   <-  100
len.p   <-  100

patt    <-  array(NA,dim=c(dim.p,dim.p,len.p))

for (i in 1:len.p)
    patt[,,i]   <-  d.tmp[(dim.p*(i-1)+1):(dim.p*i),]
