source('lib/lib_ana.R')

#here we read outputs of exp2

path.i  <-  'exp2/dat/'

zdim  <-  100
zlen  <-  1000
num.par.comb  <-  7
v.mean  <-  seq(1,num.par.comb)*.1

pat.i <-  array(NA,dim=c(num.par.comb,zdim,zdim,zlen))

for (i in 1:num.par.comb)
{
  filei <-  paste0(path.i,'exp2_',i,'.txt')
  d.tmp <-  as.matrix(read.table(filei))

  for (k in 1:zlen)
    pat.i[i,,,k] <-  d.tmp[(zdim*(k-1)+1):(zdim*k),]
}
