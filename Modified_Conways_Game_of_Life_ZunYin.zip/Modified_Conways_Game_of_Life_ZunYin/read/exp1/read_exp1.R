source('lib/lib_ana.R')

#here we read outputs of exp1

path.i  <-  'exp1/dat/'

#number of res_min, res_max, coe_min, coe_max
res.i <-  seq(.05,.95,.1)
num.res <-  length(res.i)
num.c.res <-  num.res*(num.res-1)/2

coe.i <-  seq(.05,.95,.1)
num.coe <-  length(coe.i)
num.c.coe <-  num.coe*(num.coe-1)/2

#number of simulation
num.sim <-  100

#simulation length
num.len <-  100

#[45 res comb, 45 coe comb, 100 simulation length, (mean, std)]
mean.i  <-  array(NA,dim=c(num.c.res,num.c.coe,num.len,2))

for (i in 1:(num.res-1))
for (j in (i+1):num.res)
for (k in 1:(num.coe-1))
for (l in (k+1):num.coe)
{
  filei <-  paste0(path.i,'exp1_',i,'_',j,'_',k,'_',l,'.txt')
  d.tmp <-  as.matrix(read.table(filei))

  nx  <-  GetNum(i,j)
  ny  <-  GetNum(k,l)
   
  mean.i[nx,ny,,1]  <-  apply(d.tmp,1,mean)
  mean.i[nx,ny,,2]  <-  apply(d.tmp,1,sd)
}
